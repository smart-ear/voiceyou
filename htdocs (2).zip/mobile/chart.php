<?php include_once('../head.html');?> 

	<div id="container">

		<!-- Chart 목록 -->
		<div class="list_02">
			<h2 class="hidden">Chart 목록</h2>
			<ul>
				<!-- 리스트 반복 -->
				<!--
				
				<!-- 리스트 반복 -->
<?php
 include 'db.php';

  // 데이터 베이스 연결.
  $link = connect_db($host, $dbid, $dbpw, $dbname);

  mysqli_set_charset($link, "utf8"); //한국어 인코딩 코드
   $select_query = "SELECT Nick_Name,Category, Audio_file_address, Script FROM Total_Audio_Contents"; 

   $result_set = mysqli_query($link, $select_query);


   while ($row = mysqli_fetch_array($result_set)){

     //print_r($row);
//printf("ID: %s  Name: %s", $row["Nick_Name"], $row["Audio_file_address"]); // 각각 호출
//<audio controls="controls">
//  <source src="https://s3.ap-northeast-2.amazonaws.com/storytoyou/S3_Sleep+Away.mp3" type="audio/mpeg" />
//</audio>
      echo '<br>';?>
	   
 <li class="highlight_1">

					<!--<div class="bo_num">1</div>-->
					<div class="bo_img">
						<!--<a href="" class="img"><img src="../img/chart_img_1.jpg" /></a>-->
						<!--<button type="submit" id="" class="bt_play"><img src="../img/common/btn/bt_play.png" alt="재생"></button>--> <!--이미지와 겹치는 것 하기 전 먼저 AUDIO플레이어 작게 연동함-->
						 <audio controls="controls" style="width: 80px; float:left; border:0; background:none;"><source src="<?php echo $row['Audio_file_address']; ?>" type="audio/mpeg" /></audio>
					</div>
					<div class="bo_subject">
						<a href="" class="bo_tit"><strong><?php printf($row["Script"]);?></strong></a>
						<span class="md_id"><?php printf($row["Nick_Name"]);?></span>
						<a href="" class="cate"><?php printf($row["Category"]);?></a>						
					</div>
					<div class="bo_right">
						<span class="grade">♡ 110,761,2</span>
						<span><button type="submit" id="" class=""><img src="../img/common/btn/bt_add.gif" alt="추가"></button></span>
						<span><button type="submit" id="" class=""><img src="../img/common/btn/bt_download.gif" alt="다운로드"></button></span>
						<span><a href="../mobile/comment_write.php"><img src="../img/common/btn/bt_write.gif" alt="코멘트등록"></a></span>
					</div>
				</li>

    <?php }

    mysqli_close($link);
   ?>
			</ul>
			<div class="li_more_btn">
				<button type="button" id="btn_more_item">더보기</button>
			</div>
		</div>
		
		<!--// Chart 목록 -->

</div>
<?php include_once('../tail.html');?> 