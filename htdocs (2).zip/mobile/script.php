<?php include_once('../head.html');?>

	<nav id="lnb">
		<li><a href="javascript:script();" class="on">Script</a></li>
		<li><a href="javascript:mypage();">Mypage</a></li>
	</nav>

	<div id="container2">

		<!-- Script 목록 -->
		<section id="script">
			<header>
				<h2 class="hidden">Script</h2>
			</header>
			<div id="lt">
			<ul class="list_01">
				<!-- 리스트 반복 -->
				<li>
					<div class="gall_li_wr">
						<a href="" class="gall_img">
							<img src="../img/no_image.jpg" />
							<span>01:39</span>
						</a>
						<div class="lt_info">
							<a href="" class="lt_tit"><strong>COS PRO JAVA 모의고사</strong></a>
							<span class="mb_id">voice0214</span>
							<span class="lt_date">2018.09.17</span>       
						</div>
					</div>
					<div class="lt_cate"><button type="submit" id="" class="bt_play"><img src=" ../img/common/btn/bt_play_2.png" alt="재생"></button><a href="" class="cate">자기소개</a></div>
				</li>
				<!--// 리스트 반복 -->
				<li>
					<div class="gall_li_wr">
						<a href="" class="gall_img">
							<img src="../img/image2.jpg" />
							<span>01:39</span>
						</a>
						<div class="lt_info">
							<a href="" class="lt_tit"><strong>학습과제 발표를 위한 녹음 파일</strong></a>
							<span class="mb_id">voice0214</span>
							<span class="lt_date">2018.09.17</span>       
						</div>
					</div>
					<div class="lt_cate"><button type="submit" id="" class="bt_play"><img src=" ../img/common/btn/bt_play_2.png" alt="재생"></button><a href="" class="cate">비즈니스</a></div>
				</li>
				<li>
					<div class="gall_li_wr">
						<a href="" class="gall_img">
							<img src="../img/no_image.jpg" />
							<span>03:10</span>
						</a>
						<div class="lt_info">
							<a href="" class="lt_tit"><strong>COS PRO C++ 모의고사</strong></a>
							<span class="mb_id">voice0214</span>
							<span class="lt_date">2018.09.17</span>       
						</div>
					</div>
					<div class="lt_cate"><button type="submit" id="" class="bt_play"><img src=" ../img/common/btn/bt_play_2.png" alt="재생"></button><a href="" class="cate">연설</a></div>
				</li>
				<li>
					<div class="gall_li_wr">
						<a href="" class="gall_img">
							<img src="../img/image3.jpg" />
							<span>05:22</span>
						</a>
						<div class="lt_info">
							<a href="" class="lt_tit"><strong>COS PRO JAVA 모의고사</strong></a>
							<span class="mb_id">voice0214</span>
							<span class="lt_date">2018.09.17</span>       
						</div>
					</div>
					<div class="lt_cate"><button type="submit" id="" class="bt_play"><img src=" ../img/common/btn/bt_play_2.png" alt="재생"></button><a href="" class="cate">자기소개</a></div>
				</li>
				<li>
					<div class="gall_li_wr">
						<a href="" class="gall_img">
							<img src="../img/no_image.jpg" />
							<span>01:39</span>
						</a>
						<div class="lt_info">
							<a href="" class="lt_tit"><strong>학습과제 발표를 위한 녹음 파일</strong></a>
							<span class="mb_id">voice0214</span>
							<span class="lt_date">2018.09.17</span>       
						</div>
					</div>
					<div class="lt_cate"><button type="submit" id="" class="bt_play"><img src=" ../img/common/btn/bt_play_2.png" alt="재생"></button><a href="" class="cate">비즈니스</a></div>
				</li>
				<li>
					<div class="gall_li_wr">
						<a href="" class="gall_img">
							<img src="../img/image4.jpg" />
							<span>03:10</span>
						</a>
						<div class="lt_info">
							<a href="" class="lt_tit"><strong>COS PRO C++ 모의고사</strong></a>
							<span class="mb_id">voice0214</span>
							<span class="lt_date">2018.09.17</span>       
						</div>
					</div>
					<div class="lt_cate"><button type="submit" id="" class="bt_play"><img src=" ../img/common/btn/bt_play_2.png" alt="재생"></button><a href="" class="cate">연설</a></div>
				</li>
				<li>
					<div class="gall_li_wr">
						<a href="" class="gall_img">
							<img src="../img/no_image.jpg" />
							<span>05:22</span>
						</a>
						<div class="lt_info">
							<a href="" class="lt_tit"><strong>COS PRO JAVA 모의고사</strong></a>
							<span class="mb_id">voice0214</span>
							<span class="lt_date">2018.09.17</span>       
						</div>
					</div>
					<div class="lt_cate"><button type="submit" id="" class="bt_play"><img src=" ../img/common/btn/bt_play_2.png" alt="재생"></button><a href="" class="cate">자기소개</a></div>
				</li>
				<li>
					<div class="gall_li_wr">
						<a href="" class="gall_img">
							<img src="../img/image2.jpg" />
							<span>01:39</span>
						</a>
						<div class="lt_info">
							<a href="" class="lt_tit"><strong>학습과제 발표를 위한 녹음 파일</strong></a>
							<span class="mb_id">voice0214</span>
							<span class="lt_date">2018.09.17</span>       
						</div>
					</div>
					<div class="lt_cate"><button type="submit" id="" class="bt_play"><img src=" ../img/common/btn/bt_play_2.png" alt="재생"></button><a href="" class="cate">비즈니스</a></div>
				</li>
				<li>
					<div class="gall_li_wr">
						<a href="" class="gall_img">
							<img src="../img/no_image.jpg" />
							<span>03:10</span>
						</a>
						<div class="lt_info">
							<a href="" class="lt_tit"><strong>COS PRO C++ 모의고사</strong></a>
							<span class="mb_id">voice0214</span>
							<span class="lt_date">2018.09.17</span>       
						</div>
					</div>
					<div class="lt_cate"><button type="submit" id="" class="bt_play"><img src=" ../img/common/btn/bt_play_2.png" alt="재생"></button><a href="" class="cate">연설</a></div>
				</li>
				<li>
					<div class="gall_li_wr">
						<a href="" class="gall_img">
							<img src="../img/image3.jpg" />
							<span>05:22</span>
						</a>
						<div class="lt_info">
							<a href="" class="lt_tit"><strong>COS PRO JAVA 모의고사</strong></a>
							<span class="mb_id">voice0214</span>
							<span class="lt_date">2018.09.17</span>       
						</div>
					</div>
					<div class="lt_cate"><button type="submit" id="" class="bt_play"><img src=" ../img/common/btn/bt_play_2.png" alt="재생"></button><a href="" class="cate">자기소개</a></div>
				</li>
			</ul>
			<div class="li_more_btn">
				<button type="button" id="btn_more_item">더보기</button>
			</div>
			</div>
		</section>
		<!--// Script 목록 -->

</div>
<?php include_once('../tail.html');?>