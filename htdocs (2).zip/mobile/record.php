<?php include_once('../head.html');?>

	<nav id="lnb">
		<li><a href="javascript:script();" class="on">Script</a></li>
		<li><a href="javascript:mypage();">Mypage</a></li>
	</nav>

	<div id="container">

		<section id="record">
			<header>
				<h2 class="hidden">녹음등록</h2>
			</header>
			<div class="example">기본 제공하는 스크립트 내용 예시 제공</div>

			<div class="form_01">			
			<form name="fwrite" id="fwrite" action="" onsubmit="" method="post">

			<h3>제작된 음성 파일 업로드</h3>
			<div class="bo_w_flie write_div">
				<div class="file_wr write_div">
					<label for="" class="lb_icon"><span class="sound_only"> 파일 #</span></label>
					<input type="file" name="bf_file" id="bf_file" title="파일첨부: 용량 이하만 업로드 가능" class="frm_file">
				</div>

				<span class="file_del">
					<input type="checkbox" id="bf_file_del" name="bf_file_del" value="1"> <label for="bf_file_del">파일 삭제</label>
				</span>
			</div>

			<h3>녹음</h3>
			<div class="record">
				<button type="submit" id="" class=""><img src="../img/common/btn/bt_record.png" alt="녹음"></button>
				<button type="submit" id="" class=""><img src="../img/common/btn/bt_play_off.png" alt="재생"></button>
				<button type="submit" id="" class=""><img src="../img/common/btn/bt_cut_off.png" alt="자르기"></button>				
			</div>
			<fieldset class="agree">
				<input type="checkbox" name="check_open" value="1" id="check_open" checked>
				<label for="check_open">Chart 공개</label>
				<input type="checkbox" name="check_secret" value="1" id="check_secret">
				<label for="ccheck_secret">Chart 비공개</label>
			</fieldset>
			<div class="btn_confirm">
				<a href="../mobile/record.php" class="btn_cancel btn">취소</a>
				<input type="submit" value="평가요청등록" id="btn_submit" accesskey="s" class="btn_submit btn">
			</div>
			</form>
			</div>
		</section>

</div>
<?php include_once('../tail.html');?>