<?include_once('../head.html');?>

	<div id="container3">

		<h2 class="hidden">나의 평점</h2>
			
		<!-- 그래프 및 나의 평점 -->
			<div id="graphwrap">
				<div class="graph">
					<div class="result"></div>
				</div>
				<div class="tbl_head01 tbl_wrap">
				<table>
					<tbody>
						<tr>
							<th>참여자</th>
							<td>100</td>
						</tr>
						<tr>
							<th>공감</th>
							<td>100</td>
						</tr>
						<tr>
							<th>순위</th>
							<td>10위</td>
						</tr>
					</tbody>
				</table>
				</div>

				<h3 class="type2">나의 평점<span>합계점수&nbsp; : &nbsp;85점</span></h3>
				<div class="tbl_head02 tbl_wrap">
				<table>
					<tbody>
						<tr>
							<th>발음</th>
							<td class="star"><span>★★★</span>★★</td>
							<td>3.0</td>
						</tr>
						<tr>
							<th>발성</th>
							<td class="star"><span>★★★★</span>★</td>
							<td>3.0</td>
						</tr>
						<tr>
							<th>목소리크기</th>
							<td class="star"><span>★★</span>★★★</td>
							<td>2.0</td>
						</tr>
						<tr>
							<th>속도</th>
							<td class="star"><span>★★★★</span>★</td>
							<td>4.5</td>
						</tr>
						<tr>
							<th>음색</th>
							<td class="star"><span>★★★</span>★★</td>
							<td>3.0</td>
						</tr>
					</tbody>
				</table>
				</div>
			</div>
		<!--// 그래프 및 나의 평점 -->

			<!-- 댓글 리스트 -->
			<div class="my_comment">
				<h4 class="type2">코멘트</h4>
				<div class="mb_info block">
					<img src="../img/chart_img_1.jpg" /><span class="name">voice0214</span><span class="date">2018-09-30 &nbsp; 20분</span>
				</div>
				<ul class="cm_list block">
					<li>
						<div class="comment_name">voice0214</div>						
						<div class="comment_cons">
							<div class="star"><span>★★</span>★★★</div>
							<p>그동안 플레이한 평균 티어 기반으로 산출한 결과입니다. 포지션, 티어를 고려한 시간에 따른 기대치 대비 본인이 얼마나 잘했냐를 보여줄수 있도록 최선을 다하시기 바랍니다.</p>
						</div>
					</li>
					<li>
						<div class="comment_name">voice0214</div>						
						<div class="comment_cons">
							<div class="star"><span>★★</span>★★★</div>
							<p>그동안 플레이한 평균 티어 기반으로 산출한 결과입니다. 포지션, 티어를 고려한 시간에 따른 기대치 대비 본인이 얼마나 잘했냐를 보여줄수 있도록 최선을 다하시기 바랍니다.</p>
						</div>
					</li>
					<li>
						<div class="comment_name">voice0214</div>						
						<div class="comment_cons">
							<div class="star"><span>★★</span>★★★</div>
							<p>그동안 플레이한 평균 티어 기반으로 산출한 결과입니다. 포지션, 티어를 고려한 시간에 따른 기대치 대비 본인이 얼마나 잘했냐를 보여줄수 있도록 최선을 다하시기 바랍니다.</p>
						</div>
					</li>
				</ul>
				<!-- 페이지이동 -->
				<ul class="pages">
					<li><a href="" class="btn_prev btn" title="이전글"></a></li>
					<li>
						<div><a href="" class="btn_b01 btn"><strong>1</strong></a><a href="" class="btn_b01 btn">2</a><a href="" class="btn_b01 btn">3</a><a href="" class="btn_b01 btn">4</a><a href="" class="btn_b01 btn">5</a></div>
					</li>
					<li><a href="" class="btn_next btn" title="다음글"></a></li>					
				</ul>
				<!--// 페이지이동 -->
			</div>
			<!--// 댓글 리스트 -->

			<!-- 코멘트 등록 -->
		<aside id="bo_vc_w">
			<h4 class="type3 none">코멘트 등록</h4>
			<form name="fwritecomment" id="fwritewcomment" action="" onsubmit="" method="post" autocomplete="off" class="bo_vc_w">

				<textarea id="wr_content" name="wr_content" required title="댓글 내용" placeholder="댓글내용을 입력해주세요"></textarea>
        <div class="bo_vc_w_wr">
            <div class="bo_vc_w_info">				
				<div class="tbl_head02 tbl_wrap">
				<table>
					<tbody>
						<tr>
							<th>발음</th>
							<td class="star"><span>★★★</span>★★</td>
							<td></td>
						</tr>
						<tr>
							<th>발성</th>
							<td class="star"><span>★★★★</span>★</td>
							<td></td>
						</tr>
						<tr>
							<th>목소리크기</th>
							<td class="star"><span>★★</span>★★★</td>
							<td></td>
						</tr>
						<tr>
							<th>속도</th>
							<td class="star"><span>★★★★</span>★</td>
							<td></td>
						</tr>
						<tr>
							<th>음색</th>
							<td class="star"><span>★★★</span>★★</td>
							<td></td>
						</tr>
					</tbody>
				</table>
				</div>
            </div>
            <div class="btn_confirm">
				<a href="../mobile/record.php" class="btn_cancel btn">취소</a>
                <input type="submit" id="btn_submit" class="btn_submit btn" value="댓글등록">
            </div>
		</div>

			</form>		
		</aside>
		<!--// 코멘트 등록 -->

</div>
<?include_once('../tail.html');?>