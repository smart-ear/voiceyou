/////////////////////////  VOICE YOU  //////////////////////////////////////////

function main(){window.document.location.href="/index.php";}//����

///////////////  �޴�  ///////////////
function script(){window.document.location.href="/mobile/script.php";}//
function voicetest(){window.document.location.href="/mobile/script.php";}//
function chart(){window.document.location.href="/mobile/chart.php";}//
function mypage(){window.document.location.href="/mobile/mypage.php";}//����������
function record(){window.document.location.href="/mobile/record.php";}//�������
function mygrade(){window.document.location.href="/mobile/my_grade.php";}//���� ����

/////////////// �α���  ///////////////