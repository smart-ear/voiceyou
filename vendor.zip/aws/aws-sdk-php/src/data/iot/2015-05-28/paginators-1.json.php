<?php
// This file was auto-generated from sdk-root/src/data/iot/2015-05-28/paginators-1.json
return [ 'pagination' => [],];
