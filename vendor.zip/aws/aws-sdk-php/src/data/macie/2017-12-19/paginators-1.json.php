<?php
// This file was auto-generated from sdk-root/src/data/macie/2017-12-19/paginators-1.json
return [ 'pagination' => [ 'ListMemberAccounts' => [ 'input_token' => 'nextToken', 'output_token' => 'nextToken', 'limit_key' => 'maxResults', ], 'ListS3Resources' => [ 'input_token' => 'nextToken', 'output_token' => 'nextToken', 'limit_key' => 'maxResults', ], ],];
