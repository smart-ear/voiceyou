﻿<?php session_start(); ?>
<!DOCTYPE html>
<html xml:lang="ko" xmlns="http://www.w3.org/1999/xhtml">
<head>
  <title></title>
  <meta content="text/html"; charset="utf-8"/>
  <META http-equiv="Expires" content="-1">
   <META http-equiv="Pragma" content="no-cache">
   <META http-equiv="Cache-Control" content="No-Cache">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <meta name="viewport" content="user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, width=device-width" />
  <meta http-equiv="Content-Script-Type" content="text/javascript">
  <link rel="stylesheet" type="text/css" href="../css/m_main.css">
  <link rel="shortcut icon" href="../favicon.ico">
<link rel="stylesheet" type="text/css" href="../css/menu_component.css" />
<script src="../js/modernizr.custom.js"></script>
<script type="text/javascript" src="https://static.nid.naver.com/js/naverLogin_implicit-1.0.3.js" charset="utf-8"></script>
<script type="text/javascript" src="http://code.jquery.com/jquery-1.11.3.min.js" charset="utf-8"></script>
<?php
  header('Content-Type: text/html; charset=utf-8');
?>
</head>
<body>

<?php
//session_start();

//echo ("<script language=javascript> alert('로그인에 실패하였습니다.');</script>");
// 세션에 location.href로 넘어온 값 저장
//echo ("<script>temp = location.href.split("?"); name=temp[1]; document.write(name);</script>"); //php에서 javascript 변수 사용해야될 때 쓰는 코드
	//<script language = "javascript">temp = location.href.split("?"); name=temp[1]; document.write("안녕"+name);  //html 코드에 넣고 바로 확인할 수 있음.
	// ex) <li class="topMenuLi"><a class="menuLink" href="main.php"><script language = "javascript">temp = location.href.split("?"); name=temp[1]; document.write("안녕"+name); 이런식으로

//echo("<meta http-equiv='Refresh' content='0; URL=main.php'>");
//echo '<br>';
?>
  <!-- 아이디, 비밀번호 입력하는 부분 -->
  <form class="login" action ="n_login_db.php" method="post">
    <h1><a href="main.php"><img src="../img/logo.png"></a></h1>
    <p>
        <label for="id">이름</label>
        <input type="text" id="id" name="id"> <!-- id를 미리 javascript로 설정 -->
        <label for="password">닉네임</label>
        <input type="password" id="password" name="password">
    </p>
    <p>
        <input type="submit" name="submit" value="로그인">

    </p>

  </form>
<script language = "javascript">

temp = location.href.split("?");

name=temp[1];
//data=temp[1].split(":");

//name = data[0];

//content = data[1];
//document.write("안녕"+name);
//document.getElementById("id").value = name;
$(document).ready(function() {  
        $('#id').val(name);  //위의 input에 id="id" name="id"을 설정해놓아서 값을 받아 올 수 있도록 구성 
    });


</script>
</body>
</html>
