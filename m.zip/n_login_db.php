﻿<?php
   //include 'db.php';
   // 데이터 베이스 연결.
   //$link = connect_db($host, $dbid, $dbpw, $dbname);
   //mysqli_set_charset($link, "utf8");
   // POST로 아이디 비밀번호 전달받음.
  $id = $_POST['id'];
echo $id;
   // 일치하는 아이디, 비밀번호가 있는지 체크.
  // $sql = "select * from User where ID='$id' and Password='$pw'";
   //$result = mysqli_query($link,$sql);
   //$count = mysqli_num_rows($result);


     session_start();
     // 데이터 가져오기
     //$row = mysqli_fetch_array($result);

// 세션에 아이디,비밀번호, 포인트, 이용권 정보를 저장해서 계속 사용할 수 있다.
     $_SESSION['id'] = $id;
     //$_SESSION['pw'] = $pw;

    echo("<meta http-equiv='Refresh' content='0; URL=../index.php'>");
   
 ?>
