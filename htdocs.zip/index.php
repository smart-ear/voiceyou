<?php include_once('head.php');?> 
	<!-- 메인 비쥬얼 -->
	<div id="main_bn">
        <ul class="bn_ul">
			<li class="bn_bg1">
				<img src="img/mobile/main_bn.jpg" alt="">
            </li>
            <li class="bn_bg2">
                <div class="bn_wr">
				<img src="img/mobile/main_bn2.jpg" alt="">
                </div>
            </li>
            <li class="bn_bg3">
                <div class="bn_wr">
				<img src="img/mobile/main_bn3.jpg" alt="">
                </div>
            </li>
        </ul>
        <div class="bn_btn">
            <a href="#" class="unslider-arrow prev">이전 내용</a>
            <a href="#" class="unslider-arrow next">다음 내용</a>
        </div>
	</div>
    <script>
    $(function() {
        var unslider = $("#main_bn").unslider({
            speed: 500,               //  The speed to animate each slide 슬라이드 애니메이션 속도 (in milliseconds)
            delay: 5000,              //  The delay between slide animations 슬라이드 애니메이션 사이 지연 시간(in milliseconds)
            keys: true,               //  Enable keyboard (left, right) arrow shortcuts
            dots: true,               //  Display dot navigation
            fluid: false              //  Support responsive design. May break non-responsive designs
        });
        
        $('.unslider-arrow').click(function() {
            var fn = this.className.split(' ')[1];

            //  Either do unslider.data('unslider').next() or .prev() depending on the className
            unslider.data('unslider')[fn]();
        });
    });
   </script>
	<!--// 메인 비쥬얼 -->
	<div class="banner">
		<p>VOICEYOU에서<strong>목소리에 대한 평가를 받아보세요<i>!</i></strong></p>
		<a href="">바로가기</a>
	</div>

	<div id="container" class="main">
		<section id="part1">
			<header>
				<h2>VOICE YOU</h2>
				<p>당신의 목소리를 성장 시키세요.<br>현재 나의 목소리를 분석하고 개선하는 서비스입니다.</p>
			</header>
			<ul>
				<li>
					<img src="img/part1_icon_1.png" />
						<strong>목소리 트레이닝 수요 증가</strong>
						<p>높은 수준의 목소리 및 스피치 기술을<br>원하는 사람들이 증가</p>
				</li>
				<li>
					<img src="img/part1_icon_2.png" />
						<strong>높은 가격 경쟁력</strong>
						<p>목소리 및 스피치 분석의 커리큘럼이 모바일 서비스로<br>이동함으로써 가지는 높은 가격 경쟁력</p>
				</li>
				<li>
					<img src="img/part1_icon_3.png" />
						<strong>목소리 전문가 매칭</strong>
						<p>현직 아나운서, 연설가가 나의 목소리를 직접 평가하여<br>피드백 제공</p>
				</li>
				<li>
					<img src="img/part1_icon_4.png" />
						<strong>인공지능 평가 서비스</strong>
						<p>목소리 및 스피치에 대한 빠른 피드백 니즈를<br>인공지능 기술로 해결</p>
				</li>
			</ul>
		</section>
		<section id="script">
			<header>
				<h2>VOICE TEST</h2>
				<p>보이스유를 통해 목소리에 대한 평가를 받아보세요<i>!</i><br>(전문가 견해 분석 결과를 알려드립니다.)</p>
			</header>
			<div id="lt">
			<nav id="bo_cate">
				<h2>VOICE TEST 카테고리</h2>
				<ul>
					<li><a href="">전체</a></li>
					<li><a href="">자기소개</a></li>
					<li><a href="">비즈니스</a></li>
					<li><a href="">연설</a></li>
				</ul>
			</nav>	
			<ul class="list_01">
				<!-- 리스트 반복 -->
				<li>
					<div class="gall_li_wr">
						<a href="" class="gall_img">
							<img src="img/no_image.jpg" />
							<span>01:39</span>
						</a>
						<div class="lt_info">
							<a href="" class="lt_tit"><strong>COS PRO JAVA 모의고사</strong></a>
							<span class="mb_id">voice0214</span>
							<span class="lt_date">2018.09.17</span>       
						</div>
					</div>
					<div class="lt_cate"><button type="submit" id="" class="bt_play"><img src=" ../img/common/btn/bt_play_2.png" alt="재생"></button><a href="" class="cate">자기소개</a></div>
				</li>
				<!--// 리스트 반복 -->
				<li>
					<div class="gall_li_wr">
						<a href="" class="gall_img">
							<img src="img/image2.jpg" />
							<span>01:39</span>
						</a>
						<div class="lt_info">
							<a href="" class="lt_tit"><strong>학습과제 발표를 위한 녹음 파일</strong></a>
							<span class="mb_id">voice0214</span>
							<span class="lt_date">2018.09.17</span>       
						</div>
					</div>
					<div class="lt_cate"><button type="submit" id="" class="bt_play"><img src="../img/common/btn/bt_play_2.png" alt="재생"></button><a href="" class="cate">비즈니스</a></div>
				</li>
				<li>
					<div class="gall_li_wr">
						<a href="" class="gall_img">
							<img src="img/no_image.jpg" />
							<span>03:10</span>
						</a>
						<div class="lt_info">
							<a href="" class="lt_tit"><strong>COS PRO C++ 모의고사</strong></a>
							<span class="mb_id">voice0214</span>
							<span class="lt_date">2018.09.17</span>       
						</div>
					</div>
					<div class="lt_cate"><button type="submit" id="" class="bt_play"><img src=" ../img/common/btn/bt_play_2.png" alt="재생"></button><a href="" class="cate">연설</a></div>
				</li>
				<li>
					<div class="gall_li_wr">
						<a href="" class="gall_img">
							<img src="img/image3.jpg" />
							<span>05:22</span>
						</a>
						<div class="lt_info">
							<a href="" class="lt_tit"><strong>COS PRO JAVA 모의고사</strong></a>
							<span class="mb_id">voice0214</span>
							<span class="lt_date">2018.09.17</span>       
						</div>
					</div>
					<div class="lt_cate"><button type="submit" id="" class="bt_play"><img src=" ../img/common/btn/bt_play_2.png" alt="재생"></button><a href="" class="cate">자기소개</a></div>
				</li>
				<li>
					<div class="gall_li_wr">
						<a href="" class="gall_img">
							<img src="img/no_image.jpg" />
							<span>01:39</span>
						</a>
						<div class="lt_info">
							<a href="" class="lt_tit"><strong>학습과제 발표를 위한 녹음 파일</strong></a>
							<span class="mb_id">voice0214</span>
							<span class="lt_date">2018.09.17</span>       
						</div>
					</div>
					<div class="lt_cate"><button type="submit" id="" class="bt_play"><img src=" ../img/common/btn/bt_play_2.png" alt="재생"></button><a href="" class="cate">비즈니스</a></div>
				</li>
				<li>
					<div class="gall_li_wr">
						<a href="" class="gall_img">
							<img src="img/image4.jpg" />
							<span>03:10</span>
						</a>
						<div class="lt_info">
							<a href="" class="lt_tit"><strong>COS PRO C++ 모의고사</strong></a>
							<span class="mb_id">voice0214</span>
							<span class="lt_date">2018.09.17</span>       
						</div>
					</div>
					<div class="lt_cate"><button type="submit" id="" class="bt_play"><img src=" ../img/common/btn/bt_play_2.png" alt="재생"></button><a href="" class="cate">연설</a></div>
				</li>
				<li>
					<div class="gall_li_wr">
						<a href="" class="gall_img">
							<img src="img/no_image.jpg" />
							<span>05:22</span>
						</a>
						<div class="lt_info">
							<a href="" class="lt_tit"><strong>COS PRO JAVA 모의고사</strong></a>
							<span class="mb_id">voice0214</span>
							<span class="lt_date">2018.09.17</span>       
						</div>
					</div>
					<div class="lt_cate"><button type="submit" id="" class="bt_play"><img src=" ../img/common/btn/bt_play_2.png" alt="재생"></button><a href="" class="cate">자기소개</a></div>
				</li>
			</ul>
			<div class="li_more_btn">
				<button type="button" id="btn_more_item">더보기</button>
			</div>
			</div>
		</section>
	</div>

<?php include_once('tail.html');?> 