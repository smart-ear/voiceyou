<?php session_start(); ?>
<!doctype html>
<html lang="ko">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1.0,minimum-scale=0,maximum-scale=10,user-scalable=yes">
<meta name="HandheldFriendly" content="true">
<meta name="format-detection" content="telephone=no">
<meta http-equiv="imagetoolbar" content="no">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="description" content="" />
<meta name="keywords" content="" />
<meta name="subject" content="VOICE YOU">
<meta property="og:type" content="website" />
<meta property="og:title" content="VOICE YOU" />
<meta property="og:description" content="" />
<meta property="og:image" content="" />
<meta property="og:url" content="" />
<meta property='og:site_name' content='VOICE YOU' />
<title>VOICE YOU</title>
<script src="../js/jquery-1.8.3.min.js"></script>
<script src="../js/menulink.js"></script>
<script src="../js/unslider.min.js"></script>
<link rel="canonical" href="">
<link rel="stylesheet" href="../css/mobile.css" />
</head>
<body>

<!-- 상단 시작 { -->
<header id="hd">
    <h1 id="hd_h1">VOICE YOU</h1>
    <div class="to_content"><a href="#container">본문 바로가기</a></div>

	<!-- 상단 로고 시작 -->
    <div id="hd_wr">

		<div id="logo"><a href="javascript:main();"><img src="../img/logo (2).png" alt=""></a></div>	
		<button type="button" id="gnb_open" class="hd_opener"><img src="../img/allmn.png" alt="전체메뉴"><span class="sound_only"> 메뉴열기</span></button>
		<button type="button" id="hd_submit" class="hd_search"><img src="../img/bt_search.png" alt="검색"><span class="sound_only">검색</span></button>
<!-- 로그인 안 했을 경우 메뉴-->
      <?php if(!isset($_SESSION["id"])) { ?>
	  <div id="member">
          <span id="button"><button id="btn" type="submit" onclick="location.href = '../m/login.html';"><img src="../img/login.png"></button>
            <button id="btn" type="submit" onclick="location.href='../m/register.html';"><img src="../img/register.png"></button>
          </span>
		  </div>
              <!-- 로그인 했을 경우 메뉴 -->
          <!-- 로그인 했을 경우 메뉴 -->
          <?php }else { ?>
		  <div id="member">
		  <span id="button"><a href="javascript:mygrade();"><img src="../img/icon_member.png" alt="회원아이콘"><?php echo $_SESSION["id"];?>님</a>
            <button id="btn" type="submit" onclick="location.href='logout.php';"><img src="../img/logout.png"></button>
            </span>
			</div>
			</div>
         <?php } ?>
		

		<!-- 전체메뉴 시작 -->
        <div id="gnb" class="hd_div">
            <button type="button" id="gnb_close" class="hd_closer"><span class="sound_only">메뉴 </span>닫기</button>

            <ul id="gnb_1dul">
				<li class="gnb_1dli">
					<a href="javascript:main();" class="gnb_1da">Home</a>
				</li>
				<li class="gnb_1dli">
					<a href="javascript:script();" class="gnb_1da">Voice test</a>

                    <button type="button" class="btn_gnb_op">하위분류</button>
					<ul class="gnb_2dul">
						<li class="gnb_2dli"><a href="javascript:script();" class="gnb_2da"><span></span>Script</a></li>
						<li class="gnb_2dli"><a href="javascript:mypage();" class="gnb_2da"><span></span>Mypage</a></li>		
					</ul>
				</li>
				<li class="gnb_1dli">
					<a href="javascript:chart();" class="gnb_1da">Chart</a>
				</li>
			</ul>

		</div>
        <script>
		$( document ).ready( function() {
	       var jbOffset = $( '#hd_wr' ).offset();
	      $( window ).scroll( function() {
	          if ( $( document ).scrollTop() > jbOffset.top ) {
	               $( '#hd_wr' ).addClass( 'fixed' );
	         }
		        else {
	             $( '#hd_wr' ).removeClass( 'fixed' );
	          }
	        });

            $(".hd_opener").on("click", function() {
                $(".hd_div").show();
            });

            $(".hd_search").on("click", function() {
                $("#hd_sch").show();
            });

            $("#wrapper").on("click", function() {
                $(".hd_div").hide();
                $("#hd_sch").hide();

            });

            $(".btn_gnb_op").click(function(){
                $(this).toggleClass("btn_gnb_cl").next(".gnb_2dul").slideToggle(300);
                
            });

            $(".hd_closer").on("click", function() {
                var idx = $(".hd_closer").index($(this));
                $(".hd_div:visible").hide();
                $("#hd_sch:visible").hide();
                $(".hd_opener:eq("+idx+")").find("span").text("열기");
            });

        });
        </script>
		<!--// 전체메뉴 끝 -->
		<!-- 레이어 검색창 시작 -->		
            <div id="hd_sch">
                <h2>사이트 내 전체검색</h2>
                <form name="fsearchbox" action="<?php echo G5_BBS_URL ?>/search.php" onsubmit="return fsearchbox_submit(this);" method="get">
				<button type="button" id="gnb_close" class="hd_closer"><span class="sound_only">메뉴 </span>닫기</button>
                <input type="hidden" name="sfl" value="wr_subject||wr_content">
                <input type="hidden" name="sop" value="and">
                <input type="text" name="stx" id="sch_stx" placeholder="검색어(필수)" required maxlength="20">
                <button type="submit" value="검색" id="sch_submit"><span class="sound_only">검색</span></button>
                </form>
                <script>
                function fsearchbox_submit(f)
                {
                    if (f.stx.value.length < 2) {
                        alert("검색어는 두글자 이상 입력하십시오.");
                        f.stx.select();
                        f.stx.focus();
                        return false;
                    }

                    // 검색에 많은 부하가 걸리는 경우 이 주석을 제거하세요.
                    var cnt = 0;
                    for (var i=0; i<f.stx.value.length; i++) {
                        if (f.stx.value.charAt(i) == ' ')
                            cnt++;
                    }

                    if (cnt > 1) {
                        alert("빠른 검색을 위하여 검색어에 공백은 한개만 입력할 수 있습니다.");
                        f.stx.select();
                        f.stx.focus();
                        return false;
                    }

                    return true;
                }
                </script>
            </div>
		<!--// 레이어 검색창 끝 -->

	</div>
	<!--// 상단 로고 끝 -->

	<!-- 상단 메뉴 시작 -->
	<ul id="hd_mb">
		<li><a href="javascript:main();">Home</a></li>
		<li><a href="javascript:voicetest();">Voice test</a></li>
		<li><a href="javascript:chart();"  class="on">Chart</a></li>
	</ul>
	<!-- 상단 메뉴 끝 -->
</header>
<!-- } 상단 끝 -->

<!-- 콘텐츠 시작 { -->
<div id="wrapper">
	<div id="container3">

		<h2 class="hidden">나의 평점</h2>
			
		<!-- 그래프 및 나의 평점 -->
			<div id="graphwrap">
				<div class="graph">
					<div class="result"></div>
				</div>
				<div class="tbl_head01 tbl_wrap">
				<table>
					<tbody>
						<tr>
							<th>참여자</th>
							<td>100</td>
						</tr>
						<tr>
							<th>공감</th>
							<td>100</td>
						</tr>
						<tr>
							<th>순위</th>
							<td>10위</td>
						</tr>
					</tbody>
				</table>
				</div>

				<h3 class="type2">나의 평점<span>합계점수&nbsp; : &nbsp;85점</span></h3>
				<div class="tbl_head02 tbl_wrap">
				<table>
					<tbody>
						<tr>
							<th>발음</th>
							<td class="star"><span>★★★</span>★★</td>
							<td>3.0</td>
						</tr>
						<tr>
							<th>발성</th>
							<td class="star"><span>★★★★</span>★</td>
							<td>3.0</td>
						</tr>
						<tr>
							<th>목소리크기</th>
							<td class="star"><span>★★</span>★★★</td>
							<td>2.0</td>
						</tr>
						<tr>
							<th>속도</th>
							<td class="star"><span>★★★★</span>★</td>
							<td>4.5</td>
						</tr>
						<tr>
							<th>음색</th>
							<td class="star"><span>★★★</span>★★</td>
							<td>3.0</td>
						</tr>
					</tbody>
				</table>
				</div>
			</div>
		<!--// 그래프 및 나의 평점 -->

			<!-- 댓글 리스트 -->
			<div class="my_comment">
				<h4 class="type2">코멘트</h4>
				<div class="mb_info block">
					<img src="../img/chart_img_1.jpg" /><span class="name">voice0214</span><span class="date">2018-09-30 &nbsp; 20분</span>
				</div>
				<ul class="cm_list block">
					<li>
						<div class="comment_name">voice0214</div>						
						<div class="comment_cons">
							<div class="star"><span>★★</span>★★★</div>
							<p>그동안 플레이한 평균 티어 기반으로 산출한 결과입니다. 포지션, 티어를 고려한 시간에 따른 기대치 대비 본인이 얼마나 잘했냐를 보여줄수 있도록 최선을 다하시기 바랍니다.</p>
						</div>
					</li>
					<li>
						<div class="comment_name">voice0214</div>						
						<div class="comment_cons">
							<div class="star"><span>★★</span>★★★</div>
							<p>그동안 플레이한 평균 티어 기반으로 산출한 결과입니다. 포지션, 티어를 고려한 시간에 따른 기대치 대비 본인이 얼마나 잘했냐를 보여줄수 있도록 최선을 다하시기 바랍니다.</p>
						</div>
					</li>
					<li>
						<div class="comment_name">voice0214</div>						
						<div class="comment_cons">
							<div class="star"><span>★★</span>★★★</div>
							<p>그동안 플레이한 평균 티어 기반으로 산출한 결과입니다. 포지션, 티어를 고려한 시간에 따른 기대치 대비 본인이 얼마나 잘했냐를 보여줄수 있도록 최선을 다하시기 바랍니다.</p>
						</div>
					</li>
				</ul>
				<!-- 페이지이동 -->
				<ul class="pages">
					<li><a href="" class="btn_prev btn" title="이전글"></a></li>
					<li>
						<div><a href="" class="btn_b01 btn"><strong>1</strong></a><a href="" class="btn_b01 btn">2</a><a href="" class="btn_b01 btn">3</a><a href="" class="btn_b01 btn">4</a><a href="" class="btn_b01 btn">5</a></div>
					</li>
					<li><a href="" class="btn_next btn" title="다음글"></a></li>					
				</ul>
				<!--// 페이지이동 -->
			</div>
			<!--// 댓글 리스트 -->

			<!-- 코멘트 등록 -->
		<aside id="bo_vc_w">
			<h4 class="type3 none">코멘트 등록</h4>
			<form name="fwritecomment" id="fwritewcomment" action="" onsubmit="" method="post" autocomplete="off" class="bo_vc_w">

				<textarea id="wr_content" name="wr_content" required title="댓글 내용" placeholder="댓글내용을 입력해주세요"></textarea>
        <div class="bo_vc_w_wr">
            <div class="bo_vc_w_info">				
				<div class="tbl_head02 tbl_wrap">
				<table>
					<tbody>
						<tr>
							<th>발음</th>
							<td class="star"><span>★★★</span>★★</td>
							<td></td>
						</tr>
						<tr>
							<th>발성</th>
							<td class="star"><span>★★★★</span>★</td>
							<td></td>
						</tr>
						<tr>
							<th>목소리크기</th>
							<td class="star"><span>★★</span>★★★</td>
							<td></td>
						</tr>
						<tr>
							<th>속도</th>
							<td class="star"><span>★★★★</span>★</td>
							<td></td>
						</tr>
						<tr>
							<th>음색</th>
							<td class="star"><span>★★★</span>★★</td>
							<td></td>
						</tr>
					</tbody>
				</table>
				</div>
            </div>
            <div class="btn_confirm">
				<a href="../mobile/record.php" class="btn_cancel btn">취소</a>
                <input type="submit" id="btn_submit" class="btn_submit btn" value="댓글등록">
            </div>
		</div>

			</form>		
		</aside>
		<!--// 코멘트 등록 -->

</div>
<?include_once('../tail.html');?>