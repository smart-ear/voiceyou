<?include_once('../head.html');?>

		<nav id="lnb">
			<li><a href="javascript:script();">Script</a></li>
			<li><a href="javascript:mypage();" class="on">Mypage</a></li>
		</nav>

	<div id="container3">

		<section>
			<header>
				<h2 class="hidden">Mypage</h2>
			</header>

			<!-- 그래프 및 평점 -->
			<h3 class="none block">카테고리/스크립트</h3>
			<div id="graphwrap">
				<div class="graph">
					<div class="result"></div>
				</div>
				<div class="tbl_head01 tbl_wrap">
				<table>
					<tbody>
						<tr>
							<th>참여자</th>
							<td>100</td>
						</tr>
						<tr>
							<th>공감</th>
							<td>100</td>
						</tr>
						<tr>
							<th>순위</th>
							<td>10위</td>
						</tr>
					</tbody>
				</table>
				</div>
				<div class="tbl_head02 tbl_wrap">
				<table>
					<tbody>
						<tr>
							<th>발음</th>
							<td class="star"><span>★★★</span>★★</td>
							<td>3.0</td>
						</tr>
						<tr>
							<th>발성</th>
							<td class="star"><span>★★★★</span>★</td>
							<td>3.0</td>
						</tr>
						<tr>
							<th>목소리크기</th>
							<td class="star"><span>★★</span>★★★</td>
							<td>2.0</td>
						</tr>
						<tr>
							<th>속도</th>
							<td class="star"><span>★★★★</span>★</td>
							<td>4.5</td>
						</tr>
						<tr>
							<th>음색</th>
							<td class="star"><span>★★★</span>★★</td>
							<td>3.0</td>
						</tr>
					</tbody>
				</table>
				</div>
			</div>
			<!--// 그래프 및 평점 -->

			<!-- 전문가 견해 -->
			<div id="view">
				<h3 class="none">전문가 견해<a href="" class="bt_guide btn">가이드 제공</a></h3>
				<p class="contents">인간의 목소리 수준의 자연스러움을 생성할 수 있는 사용자 기반 딥러닝 음성합성 기술과 영상 캡셔닝 기술을 통합하여 꾸준한 노력이 필요합니다.</p>
			</div>
			<!--// 전문가 견해 -->

			<!-- 댓글 리스트 -->
			<div class="comment block">
				<h4>댓글</h4>
				<ul class="cm_list">
					<li>
						<span class="comment_name">voice0214</span>
						<span class="comment_date">(2018.09.30)</span>
						<div>그동안 플레이한 평균 티어 기반으로 산출한 결과입니다. 포지션, 티어를 고려한 시간에 따른 기대치 대비 본인이 얼마나 잘했냐를 보여줄수 있도록 최선을 다하시기 바랍니다.</div>
					</li>
					<li>
						<span class="comment_name">voice0214</span>
						<span class="comment_date">(2018.09.30)</span>
						<div>그동안 플레이한 평균 티어 기반으로 산출한 결과입니다. 포지션, 티어를 고려한 시간에 따른 기대치 대비 본인이 얼마나 잘했냐를 보여줄수 있도록 최선을 다하시기 바랍니다.</div>
					</li>
					<li>
						<span class="comment_name">voice0214</span>
						<span class="comment_date">(2018.09.30)</span>
						<div>그동안 플레이한 평균 티어 기반으로 산출한 결과입니다. 포지션, 티어를 고려한 시간에 따른 기대치 대비 본인이 얼마나 잘했냐를 보여줄수 있도록 최선을 다하시기 바랍니다.</div>
					</li>
				</ul>
				<!-- 페이지이동 -->
				<ul class="pages">
					<li><a href="" class="btn_prev btn" title="이전글"></a></li>
					<li>
						<div><a href="" class="btn_b01 btn"><strong>1</strong></a><a href="" class="btn_b01 btn">2</a><a href="" class="btn_b01 btn">3</a><a href="" class="btn_b01 btn">4</a><a href="" class="btn_b01 btn">5</a></div>
					</li>
					<li><a href="" class="btn_next btn" title="다음글"></a></li>					
				</ul>
				<!--// 페이지이동 -->
			</div>
			<!--// 댓글 리스트 -->

		</section>

</div>
<?include_once('../tail.html');?>